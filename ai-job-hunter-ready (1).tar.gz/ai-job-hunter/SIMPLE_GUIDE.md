# How to Get Your AI Job Hunter Website Live
## Super Simple Guide for Beginners

Follow these steps exactly. You do **not** need to know programming.

---

## Part 1: Download and Upload to GitHub

### Step 1: Download the ZIP file
- I will give you a download link for the complete project ZIP.
- Download it to your computer and **unzip** it.
- You will see a folder called `ai-job-hunter`.

### Step 2: Create a free GitHub account
1. Go to [https://github.com](https://github.com)
2. Click **Sign up**
3. Create your free account (use your email)

### Step 3: Create a new repository
1. After logging in, click the **+** button (top right) → **New repository**
2. Name it: `ai-job-hunter`
3. Leave everything else as default
4. Click **Create repository**

### Step 4: Upload the files
1. On the new repository page, click the link that says **"uploading an existing file"**
2. Open the unzipped `ai-job-hunter` folder on your computer
3. Select **all files and folders** inside it
4. Drag and drop them into the GitHub upload area
5. Scroll down and click **Commit changes**

Your code is now on GitHub.

---

## Part 2: Deploy the Backend on Render (this creates the database too)

1. Go to [https://render.com](https://render.com)
2. Click **Get Started** or **Sign Up** and sign in with your **GitHub** account
3. Click **New** → **Blueprint**
4. Find and select your `ai-job-hunter` repository
5. Click **Connect**
6. Render will automatically detect the settings. Just click **Apply**
7. Wait 4–6 minutes. You will see two things being created:
   - A database
   - A web service called `ai-job-hunter-api`
8. When it says **Live**, click on the web service
9. Copy the URL at the top (it looks like `https://ai-job-hunter-api.onrender.com`)

**Save this URL** — you will need it in the next step.

---

## Part 3: Deploy the Frontend on Vercel

1. Go to [https://vercel.com](https://vercel.com)
2. Click **Sign Up** and sign in with your **GitHub** account
3. Click **Add New** → **Project**
4. Select your `ai-job-hunter` repository and click **Import**
5. Important settings:
   - **Root Directory**: Click **Edit** and type `frontend`
   - Under **Environment Variables**, click **Add**:
     - Name: `NEXT_PUBLIC_API_URL`
     - Value: paste the Render URL you copied earlier (example: `https://ai-job-hunter-api.onrender.com`)
6. Click **Deploy**
7. Wait 2–3 minutes
8. When it finishes, you will see a big **Visit** button or a URL like `https://ai-job-hunter.vercel.app`

**This is your live website!** Open it in any browser.

---

## Part 4: Test Your Live Website

1. Open the Vercel URL
2. Click **Register** and create an account
3. Go to **Resume** and upload any PDF or Word file
4. Go to **Jobs** — you should see job listings with match scores
5. Click **Prepare Application** on a job
6. Go to **Applications** to see it tracked

---

## Important Notes

- The first time you open the site after a few hours, it may take 30–50 seconds to load (Render free plan sleeps). This is normal.
- All data is saved in a real database on Render.
- Your website is public — anyone with the link can visit it.

---

## If Something Goes Wrong

| Problem | What to do |
|---------|------------|
| Site won’t load | Wait 1 minute and refresh. Check that the Render service is “Live”. |
| “Cannot connect” or CORS error | In Render, go to your service → Environment → add `ALLOWED_ORIGINS` = `*` and redeploy. |
| Jobs or login not working | Make sure the `NEXT_PUBLIC_API_URL` in Vercel is exactly the Render URL (no extra slash at the end). |

That’s it! You now have a live AI Job Hunter website.
