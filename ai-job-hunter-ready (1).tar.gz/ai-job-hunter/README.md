# AI Job Hunter

## Backend (FastAPI)

### Setup

```bash
cd backend
pip install -r requirements.txt
# Optional: playwright install chromium (may require system deps)
python main.py
```

API runs at http://localhost:8000
Docs: http://localhost:8000/docs

### Environment Variables

- `SECRET_KEY`: JWT secret (change in production)
- For real AI: set `OPENAI_API_KEY` or similar and extend the generate functions

### Features Implemented

- User registration & JWT auth
- User settings
- Resume upload (PDF/DOCX) + basic skill extraction
- Job listing with compatibility scoring (rule-based)
- Cover letter generation (template-based)
- Application tracking
- Dashboard stats
- Sample jobs seeded

### Limitations (Honest)

- Job search uses sample data. Real LinkedIn/Indeed/Glassdoor scraping is blocked by most sites and against ToS. Use official APIs where available (e.g., some company career pages, Adzuna, etc.).
- Auto-apply is simulated. Real Playwright automation only works on sites that explicitly permit it and after user consent. CAPTCHAs and login walls cannot be bypassed.
- AI matching and cover letters are rule/template based. Plug in a real LLM (OpenAI, Anthropic, etc.) by replacing the helper functions.
- Database is SQLite for easy local run. Switch to PostgreSQL for production (change SQLALCHEMY_DATABASE_URL).

## Frontend (Next.js)

### Setup

```bash
cd frontend
npm install   # if not already done by create-next-app
npm run dev
```

Open http://localhost:3000

The frontend talks to the backend at http://localhost:8000 (configurable via NEXT_PUBLIC_API_URL).

### Running the Full App

1. Start backend: `cd backend && python main.py`
2. Start frontend: `cd frontend && npm run dev`
3. Register a user, upload a resume (PDF/DOCX), browse jobs, prepare applications.

### Production Notes

- Switch backend to PostgreSQL
- Add real LLM provider (OpenAI etc.) for better matching and cover letters
- Implement official job APIs or permitted scrapers
- Deploy backend (e.g. Railway, Render) and frontend (Vercel)
- Use proper secrets management
- Add rate limiting, logging, monitoring

## Architecture

- **Backend**: FastAPI + SQLAlchemy + SQLite (dev)
- **Frontend**: Next.js 16 App Router + Tailwind
- **Auth**: JWT
- **AI**: Rule-based scoring + template cover letters (extensible to LLM)
- **Automation**: Simulated (Playwright ready but restricted by site policies)

All major features are implemented and functional within the constraints of public web access and security rules.
