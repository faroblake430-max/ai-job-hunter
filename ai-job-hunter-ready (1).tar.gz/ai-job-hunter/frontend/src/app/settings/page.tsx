'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export default function SettingsPage() {
  const [token, setToken] = useState<string | null>(null);
  const [settings, setSettings] = useState<any>({
    job_titles: '',
    skills: '',
    experience_level: 'mid',
    preferred_countries: '',
    remote_preference: 'any',
    min_salary: 0,
    employment_type: 'any',
    daily_application_limit: 10,
    auto_apply_enabled: false,
    require_approval: true
  });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    const t = localStorage.getItem('token');
    if (!t) {
      window.location.href = '/';
      return;
    }
    setToken(t);
    fetch(`${API_BASE}/settings`, { headers: { Authorization: `Bearer ${t}` } })
      .then(r => r.json())
      .then(data => {
        setSettings({
          ...data,
          job_titles: (data.job_titles || []).join(', '),
          skills: (data.skills || []).join(', '),
          preferred_countries: (data.preferred_countries || []).join(', ')
        });
      });
  }, []);

  const save = async () => {
    if (!token) return;
    const payload = {
      ...settings,
      job_titles: settings.job_titles.split(',').map((s: string) => s.trim()).filter(Boolean),
      skills: settings.skills.split(',').map((s: string) => s.trim()).filter(Boolean),
      preferred_countries: settings.preferred_countries.split(',').map((s: string) => s.trim()).filter(Boolean)
    };
    const res = await fetch(`${API_BASE}/settings`, {
      method: 'PUT',
      headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    if (res.ok) {
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white p-6">
      <div className="max-w-2xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Settings</h1>
          <Link href="/" className="text-blue-400 hover:underline">← Dashboard</Link>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 space-y-4">
          <div>
            <label className="block text-sm text-slate-400 mb-1">Job Titles (comma separated)</label>
            <input value={settings.job_titles} onChange={e => setSettings({...settings, job_titles: e.target.value})} className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded" />
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Skills (comma separated)</label>
            <input value={settings.skills} onChange={e => setSettings({...settings, skills: e.target.value})} className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded" />
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Experience Level</label>
            <select value={settings.experience_level} onChange={e => setSettings({...settings, experience_level: e.target.value})} className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded">
              <option value="junior">Junior</option>
              <option value="mid">Mid</option>
              <option value="senior">Senior</option>
              <option value="lead">Lead</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Preferred Countries</label>
            <input value={settings.preferred_countries} onChange={e => setSettings({...settings, preferred_countries: e.target.value})} className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded" />
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Remote Preference</label>
            <select value={settings.remote_preference} onChange={e => setSettings({...settings, remote_preference: e.target.value})} className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded">
              <option value="any">Any</option>
              <option value="remote">Remote</option>
              <option value="onsite">Onsite</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Minimum Salary</label>
            <input type="number" value={settings.min_salary} onChange={e => setSettings({...settings, min_salary: parseInt(e.target.value) || 0})} className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded" />
          </div>
          <div>
            <label className="block text-sm text-slate-400 mb-1">Daily Application Limit</label>
            <input type="number" value={settings.daily_application_limit} onChange={e => setSettings({...settings, daily_application_limit: parseInt(e.target.value) || 10})} className="w-full px-3 py-2 bg-slate-800 border border-slate-700 rounded" />
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={settings.auto_apply_enabled} onChange={e => setSettings({...settings, auto_apply_enabled: e.target.checked})} id="auto" />
            <label htmlFor="auto">Enable Auto-Apply (requires approval & permitted sites)</label>
          </div>
          <div className="flex items-center gap-2">
            <input type="checkbox" checked={settings.require_approval} onChange={e => setSettings({...settings, require_approval: e.target.checked})} id="approve" />
            <label htmlFor="approve">Require Manual Approval Before Submit</label>
          </div>
          <button onClick={save} className="w-full bg-blue-600 hover:bg-blue-700 py-3 rounded-lg font-semibold mt-4">
            {saved ? 'Saved!' : 'Save Settings'}
          </button>
        </div>
        <p className="mt-4 text-xs text-slate-500">
          Auto-apply only works on websites that explicitly allow automation and after explicit user consent. 
          Most major job boards block automated submissions.
        </p>
      </div>
    </div>
  );
}
