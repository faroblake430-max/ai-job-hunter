'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export default function ApplicationsPage() {
  const [apps, setApps] = useState<any[]>([]);
  const [token, setToken] = useState<string | null>(null);

  useEffect(() => {
    const t = localStorage.getItem('token');
    if (!t) {
      window.location.href = '/';
      return;
    }
    setToken(t);
    fetchApps(t);
  }, []);

  const fetchApps = async (t: string) => {
    const res = await fetch(`${API_BASE}/applications`, {
      headers: { Authorization: `Bearer ${t}` }
    });
    if (res.ok) setApps(await res.json());
  };

  const submit = async (id: number) => {
    if (!token) return;
    const res = await fetch(`${API_BASE}/applications/${id}/apply`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` }
    });
    const data = await res.json();
    alert(data.message);
    fetchApps(token);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white p-6">
      <div className="max-w-5xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Application Tracker</h1>
          <Link href="/" className="text-blue-400 hover:underline">← Dashboard</Link>
        </div>
        <div className="space-y-4">
          {apps.map(app => (
            <div key={app.id} className="bg-slate-900 border border-slate-800 rounded-xl p-5">
              <div className="flex justify-between">
                <div>
                  <h2 className="text-lg font-semibold">{app.job_title}</h2>
                  <p className="text-slate-400">{app.company}</p>
                  <p className="text-sm mt-1">Score: {app.compatibility_score}% • Status: <span className="capitalize font-medium text-blue-300">{app.status}</span></p>
                </div>
                {app.status === 'ready' && (
                  <button onClick={() => submit(app.id)} className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-sm h-fit">
                    Mark as Applied
                  </button>
                )}
              </div>
              <p className="mt-3 text-sm text-slate-400 italic">"{app.cover_letter_preview}"</p>
              <a href={app.url} target="_blank" className="text-blue-400 text-sm mt-2 inline-block">Job Link →</a>
            </div>
          ))}
          {apps.length === 0 && <p className="text-slate-400">No applications yet. Prepare some from the Jobs page.</p>}
        </div>
      </div>
    </div>
  );
}
