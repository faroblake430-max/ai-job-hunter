'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export default function ResumePage() {
  const [token, setToken] = useState<string | null>(null);
  const [resumes, setResumes] = useState<any[]>([]);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState<any>(null);

  useEffect(() => {
    const t = localStorage.getItem('token');
    if (!t) {
      window.location.href = '/';
      return;
    }
    setToken(t);
    fetchResumes(t);
  }, []);

  const fetchResumes = async (t: string) => {
    const res = await fetch(`${API_BASE}/resumes`, { headers: { Authorization: `Bearer ${t}` } });
    if (res.ok) setResumes(await res.json());
  };

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !token) return;
    setUploading(true);
    setResult(null);
    const form = new FormData();
    form.append('file', file);
    try {
      const res = await fetch(`${API_BASE}/resumes/upload`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: form
      });
      const data = await res.json();
      if (res.ok) {
        setResult(data);
        fetchResumes(token);
      } else {
        alert(data.detail || 'Upload failed');
      }
    } catch (err) {
      alert('Error uploading');
    }
    setUploading(false);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white p-6">
      <div className="max-w-3xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Resume Analyzer</h1>
          <Link href="/" className="text-blue-400 hover:underline">← Dashboard</Link>
        </div>
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-6 mb-6">
          <h2 className="text-lg font-semibold mb-4">Upload CV (PDF or DOCX)</h2>
          <input type="file" accept=".pdf,.docx" onChange={handleUpload} disabled={uploading} className="text-sm" />
          {uploading && <p className="mt-2 text-blue-400">Analyzing...</p>}
          {result && (
            <div className="mt-4 p-4 bg-slate-800 rounded-lg">
              <p className="font-medium">Uploaded: {result.filename}</p>
              <p className="mt-2">Extracted Skills: {result.skills.join(', ') || 'None detected'}</p>
              <p className="mt-2 text-sm text-slate-400">Preview: {result.preview}</p>
            </div>
          )}
        </div>
        <h2 className="text-xl font-semibold mb-4">Your Resumes</h2>
        <div className="space-y-3">
          {resumes.map(r => (
            <div key={r.id} className="bg-slate-900 border border-slate-800 p-4 rounded-lg">
              <p className="font-medium">{r.filename}</p>
              <p className="text-sm text-slate-400">Skills: {r.skills.join(', ') || 'N/A'}</p>
              <p className="text-xs text-slate-500">{new Date(r.uploaded_at).toLocaleDateString()}</p>
            </div>
          ))}
          {resumes.length === 0 && <p className="text-slate-400">No resumes uploaded yet.</p>}
        </div>
      </div>
    </div>
  );
}
