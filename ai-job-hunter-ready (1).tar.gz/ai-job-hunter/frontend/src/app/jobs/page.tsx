'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export default function JobsPage() {
  const [jobs, setJobs] = useState<any[]>([]);
  const [token, setToken] = useState<string | null>(null);
  const [filter, setFilter] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const t = localStorage.getItem('token');
    if (!t) {
      window.location.href = '/';
      return;
    }
    setToken(t);
    fetchJobs(t);
  }, []);

  const fetchJobs = async (t: string) => {
    setLoading(true);
    try {
      const res = await fetch(`${API_BASE}/jobs?title=${encodeURIComponent(filter)}`, {
        headers: { Authorization: `Bearer ${t}` }
      });
      if (res.ok) setJobs(await res.json());
    } catch (e) {
      console.error(e);
    }
    setLoading(false);
  };

  const prepareApplication = async (jobId: number) => {
    if (!token) return;
    try {
      const res = await fetch(`${API_BASE}/applications`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ job_id: jobId })
      });
      if (res.ok) {
        alert('Application prepared! Check Applications page to review and submit.');
      } else {
        alert('Failed to prepare application');
      }
    } catch (e) {
      alert('Error');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold">Job Listings</h1>
          <Link href="/" className="text-blue-400 hover:underline">← Dashboard</Link>
        </div>
        <div className="mb-6 flex gap-2">
          <input
            value={filter}
            onChange={e => setFilter(e.target.value)}
            placeholder="Filter by title..."
            className="flex-1 px-4 py-2 bg-slate-800 border border-slate-700 rounded-lg"
            onKeyDown={e => e.key === 'Enter' && token && fetchJobs(token)}
          />
          <button onClick={() => token && fetchJobs(token)} className="bg-blue-600 px-4 py-2 rounded-lg">Search</button>
        </div>
        {loading ? <p>Loading...</p> : (
          <div className="space-y-4">
            {jobs.map(job => (
              <div key={job.id} className="bg-slate-900 border border-slate-800 rounded-xl p-6 hover:border-slate-700 transition">
                <div className="flex justify-between items-start">
                  <div>
                    <h2 className="text-xl font-semibold">{job.title}</h2>
                    <p className="text-slate-400">{job.company} • {job.location} {job.remote && '• Remote'}</p>
                    <p className="text-sm text-slate-500 mt-1">Source: {job.source} • ${job.salary_min.toLocaleString()} - ${job.salary_max.toLocaleString()}</p>
                  </div>
                  {job.compatibility_score && (
                    <div className="text-right">
                      <span className={`text-2xl font-bold ${job.compatibility_score >= 70 ? 'text-green-400' : job.compatibility_score >= 50 ? 'text-yellow-400' : 'text-red-400'}`}>
                        {job.compatibility_score}%
                      </span>
                      <p className="text-xs text-slate-500">match</p>
                    </div>
                  )}
                </div>
                <p className="mt-4 text-slate-300 text-sm">{job.description}</p>
                <div className="mt-4 flex gap-3">
                  <a href={job.url} target="_blank" rel="noopener" className="text-blue-400 hover:underline text-sm">View Job →</a>
                  <button onClick={() => prepareApplication(job.id)} className="bg-emerald-600 hover:bg-emerald-700 px-4 py-1.5 rounded text-sm">
                    Prepare Application
                  </button>
                </div>
              </div>
            ))}
            {jobs.length === 0 && <p className="text-slate-400">No jobs found. Try uploading a resume first for better matching.</p>}
          </div>
        )}
      </div>
    </div>
  );
}
