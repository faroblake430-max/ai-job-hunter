'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';

const API_BASE = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export default function Home() {
  const [token, setToken] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [isRegister, setIsRegister] = useState(false);
  const [error, setError] = useState('');
  const [dashboard, setDashboard] = useState<any>(null);

  useEffect(() => {
    const t = localStorage.getItem('token');
    if (t) {
      setToken(t);
      fetchDashboard(t);
    }
  }, []);

  const fetchDashboard = async (t: string) => {
    try {
      const res = await fetch(`${API_BASE}/dashboard`, {
        headers: { Authorization: `Bearer ${t}` }
      });
      if (res.ok) {
        setDashboard(await res.json());
      } else {
        localStorage.removeItem('token');
        setToken(null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    try {
      if (isRegister) {
        const res = await fetch(`${API_BASE}/register`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password, full_name: fullName })
        });
        if (!res.ok) throw new Error((await res.json()).detail || 'Register failed');
        setIsRegister(false);
        alert('Registered! Please login.');
      } else {
        const form = new URLSearchParams();
        form.append('username', email);
        form.append('password', password);
        const res = await fetch(`${API_BASE}/token`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: form
        });
        if (!res.ok) throw new Error('Login failed');
        const data = await res.json();
        localStorage.setItem('token', data.access_token);
        setToken(data.access_token);
        fetchDashboard(data.access_token);
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    setToken(null);
    setDashboard(null);
  };

  if (!token) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center p-4">
        <div className="bg-slate-800/80 backdrop-blur p-8 rounded-2xl shadow-2xl w-full max-w-md border border-slate-700">
          <h1 className="text-3xl font-bold text-white mb-2 text-center">AI Job Hunter</h1>
          <p className="text-slate-400 text-center mb-6">Smart job matching & applications</p>
          <form onSubmit={handleAuth} className="space-y-4">
            {isRegister && (
              <input
                type="text"
                placeholder="Full Name"
                value={fullName}
                onChange={e => setFullName(e.target.value)}
                className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            )}
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={e => setPassword(e.target.value)}
              className="w-full px-4 py-3 bg-slate-700 border border-slate-600 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-blue-500"
              required
            />
            {error && <p className="text-red-400 text-sm">{error}</p>}
            <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition">
              {isRegister ? 'Register' : 'Login'}
            </button>
          </form>
          <button onClick={() => setIsRegister(!isRegister)} className="mt-4 text-blue-400 hover:underline w-full text-center">
            {isRegister ? 'Already have an account? Login' : 'Need an account? Register'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-white">
      <nav className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex justify-between items-center">
        <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">AI Job Hunter</h1>
        <div className="flex gap-4 items-center">
          <Link href="/jobs" className="hover:text-blue-400">Jobs</Link>
          <Link href="/applications" className="hover:text-blue-400">Applications</Link>
          <Link href="/settings" className="hover:text-blue-400">Settings</Link>
          <Link href="/resume" className="hover:text-blue-400">Resume</Link>
          <button onClick={logout} className="text-sm bg-slate-700 hover:bg-slate-600 px-3 py-1 rounded">Logout</button>
        </div>
      </nav>
      <main className="p-6 max-w-7xl mx-auto">
        <h2 className="text-3xl font-bold mb-8">Dashboard</h2>
        {dashboard ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard title="Total Jobs" value={dashboard.total_jobs_found} color="blue" />
            <StatCard title="Matching Jobs" value={dashboard.matching_jobs} color="green" />
            <StatCard title="Applied" value={dashboard.applications_submitted} color="purple" />
            <StatCard title="Pending" value={dashboard.pending_applications} color="yellow" />
          </div>
        ) : (
          <p>Loading dashboard...</p>
        )}
        <div className="mt-12">
          <h3 className="text-xl font-semibold mb-4">Quick Actions</h3>
          <div className="flex flex-wrap gap-4">
            <Link href="/jobs" className="bg-blue-600 hover:bg-blue-700 px-6 py-3 rounded-lg font-medium">Browse Jobs</Link>
            <Link href="/resume" className="bg-slate-700 hover:bg-slate-600 px-6 py-3 rounded-lg font-medium">Upload Resume</Link>
            <Link href="/applications" className="bg-slate-700 hover:bg-slate-600 px-6 py-3 rounded-lg font-medium">View Applications</Link>
          </div>
        </div>
        <div className="mt-12 p-6 bg-slate-900 rounded-xl border border-slate-800">
          <h3 className="font-semibold mb-2">Note on Features</h3>
          <p className="text-slate-400 text-sm">
            This is a functional MVP. Job data is sample data (real site scraping is restricted). 
            Compatibility scoring is rule-based. Cover letters use templates. 
            Auto-apply is simulated with manual confirmation. Connect a real LLM API for advanced generation.
          </p>
        </div>
      </main>
    </div>
  );
}

function StatCard({ title, value, color }: { title: string; value: number; color: string }) {
  const colors: any = {
    blue: 'from-blue-500 to-blue-600',
    green: 'from-emerald-500 to-emerald-600',
    purple: 'from-violet-500 to-violet-600',
    yellow: 'from-amber-500 to-amber-600'
  };
  return (
    <div className={`bg-gradient-to-br ${colors[color]} p-6 rounded-xl shadow-lg`}>
      <p className="text-white/80 text-sm">{title}</p>
      <p className="text-4xl font-bold mt-2">{value}</p>
    </div>
  );
}
