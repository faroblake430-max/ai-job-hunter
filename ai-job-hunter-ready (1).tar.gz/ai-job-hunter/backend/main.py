from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, Boolean, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session, relationship
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, timedelta
from jose import JWTError, jwt
from passlib.context import CryptContext
import pdfplumber
import docx
import io
import os
import json
import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./jobhunter.db")

# Render provides postgres:// but SQLAlchemy needs postgresql://
if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    engine = create_engine(DATABASE_URL)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Security
SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key-change-me-in-production-please-use-long-random-string")
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24 * 7  # 7 days

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="token")

# Models
class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True)
    hashed_password = Column(String)
    full_name = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    settings = relationship("UserSettings", back_populates="user", uselist=False)
    resumes = relationship("Resume", back_populates="user")
    applications = relationship("Application", back_populates="user")

class UserSettings(Base):
    __tablename__ = "user_settings"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    job_titles = Column(Text, default="[]")  # JSON list
    skills = Column(Text, default="[]")
    experience_level = Column(String, default="mid")
    preferred_countries = Column(Text, default="[]")
    remote_preference = Column(String, default="any")  # remote, onsite, any
    min_salary = Column(Integer, default=0)
    employment_type = Column(String, default="any")  # fulltime, contract, any
    daily_application_limit = Column(Integer, default=10)
    auto_apply_enabled = Column(Boolean, default=False)
    require_approval = Column(Boolean, default=True)
    user = relationship("User", back_populates="settings")

class Resume(Base):
    __tablename__ = "resumes"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    filename = Column(String)
    content = Column(Text)  # extracted text
    skills = Column(Text, default="[]")
    experience = Column(Text, default="")
    education = Column(Text, default="")
    uploaded_at = Column(DateTime, default=datetime.utcnow)
    user = relationship("User", back_populates="resumes")

class Job(Base):
    __tablename__ = "jobs"
    id = Column(Integer, primary_key=True)
    title = Column(String, index=True)
    company = Column(String)
    location = Column(String)
    remote = Column(Boolean, default=False)
    salary_min = Column(Integer, default=0)
    salary_max = Column(Integer, default=0)
    description = Column(Text)
    url = Column(String, unique=True)
    source = Column(String)  # linkedin, indeed, etc.
    posted_date = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)
    employment_type = Column(String, default="fulltime")
    required_skills = Column(Text, default="[]")

class Application(Base):
    __tablename__ = "applications"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id"))
    job_id = Column(Integer, ForeignKey("jobs.id"))
    resume_id = Column(Integer, ForeignKey("resumes.id"), nullable=True)
    status = Column(String, default="saved")  # saved, ready, applied, interview, rejected, offer
    cover_letter = Column(Text)
    applied_at = Column(DateTime, nullable=True)
    notes = Column(Text)
    compatibility_score = Column(Float, default=0.0)
    user = relationship("User", back_populates="applications")
    job = relationship("Job")

Base.metadata.create_all(bind=engine)

# Pydantic schemas
class UserCreate(BaseModel):
    email: str
    password: str
    full_name: str

class UserSettingsUpdate(BaseModel):
    job_titles: List[str] = []
    skills: List[str] = []
    experience_level: str = "mid"
    preferred_countries: List[str] = []
    remote_preference: str = "any"
    min_salary: int = 0
    employment_type: str = "any"
    daily_application_limit: int = 10
    auto_apply_enabled: bool = False
    require_approval: bool = True

class JobResponse(BaseModel):
    id: int
    title: str
    company: str
    location: str
    remote: bool
    salary_min: int
    salary_max: int
    description: str
    url: str
    source: str
    compatibility_score: Optional[float] = None

class ApplicationCreate(BaseModel):
    job_id: int
    resume_id: Optional[int] = None
    cover_letter: Optional[str] = None

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def verify_password(plain, hashed):
    return pwd_context.verify(plain, hashed)

def get_password_hash(password):
    return pwd_context.hash(password)

def create_access_token(data: dict):
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)

async def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)):
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        email: str = payload.get("sub")
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = db.query(User).filter(User.email == email).first()
    if user is None:
        raise credentials_exception
    return user

# AI / Matching helpers (simple rule-based for demo; plug in real LLM)
def extract_text_from_pdf(file_bytes):
    try:
        with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
            text = "\n".join(page.extract_text() or "" for page in pdf.pages)
        return text
    except Exception as e:
        logger.error(f"PDF extract error: {e}")
        return ""

def extract_text_from_docx(file_bytes):
    try:
        doc = docx.Document(io.BytesIO(file_bytes))
        return "\n".join(p.text for p in doc.paragraphs)
    except Exception as e:
        logger.error(f"DOCX extract error: {e}")
        return ""

def simple_skill_extract(text: str) -> List[str]:
    # Very basic keyword extraction
    common_skills = [
        "python", "javascript", "react", "next.js", "fastapi", "sql", "postgresql",
        "aws", "docker", "kubernetes", "machine learning", "ai", "typescript",
        "node.js", "java", "c++", "go", "rust", "tailwind", "html", "css",
        "git", "agile", "scrum", "rest", "api", "postgresql", "mongodb"
    ]
    text_lower = text.lower()
    return [s for s in common_skills if s in text_lower]

def calculate_compatibility(resume_skills: List[str], job_required: List[str], resume_text: str, job_desc: str) -> float:
    if not job_required:
        return 50.0
    resume_set = set(s.lower() for s in resume_skills)
    job_set = set(s.lower() for s in job_required)
    overlap = len(resume_set & job_set)
    score = (overlap / max(len(job_set), 1)) * 80 + 20  # base 20
    # simple keyword density bonus
    if any(kw in job_desc.lower() for kw in resume_set):
        score += 10
    return min(100.0, max(0.0, score))

def generate_cover_letter(user_name: str, job_title: str, company: str, resume_summary: str, job_desc: str) -> str:
    # Template-based (replace with real LLM call when API key present)
    return f"""Dear Hiring Manager,

I am writing to express my strong interest in the {job_title} position at {company}. With my background in {resume_summary[:200]}..., I am confident that my skills and experience align well with the requirements outlined in the job description.

{job_desc[:300]}... I am particularly drawn to the opportunity to contribute to your team and am excited about the potential to grow with {company}.

I have attached my resume for your review and would welcome the chance to discuss how I can contribute to your organization. Thank you for considering my application.

Sincerely,
{user_name}
"""

app = FastAPI(title="AI Job Hunter API", version="1.0.0")

# CORS - allow frontend
allowed_origins = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000,http://127.0.0.1:3000,*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Sample data seed
def seed_sample_jobs(db: Session):
    if db.query(Job).count() > 0:
        return
    sample_jobs = [
        {
            "title": "Senior Python Backend Engineer",
            "company": "TechCorp Inc",
            "location": "Remote / San Francisco",
            "remote": True,
            "salary_min": 140000,
            "salary_max": 180000,
            "description": "We are looking for a Senior Python engineer with FastAPI, PostgreSQL, and cloud experience. Must have 5+ years experience building scalable APIs.",
            "url": "https://example.com/jobs/senior-python",
            "source": "company",
            "required_skills": json.dumps(["python", "fastapi", "postgresql", "aws", "docker"])
        },
        {
            "title": "Frontend React Developer",
            "company": "StartupXYZ",
            "location": "New York, NY",
            "remote": False,
            "salary_min": 110000,
            "salary_max": 140000,
            "description": "Join our team to build modern React and Next.js applications. Experience with Tailwind CSS and TypeScript preferred.",
            "url": "https://example.com/jobs/react-dev",
            "source": "indeed",
            "required_skills": json.dumps(["react", "next.js", "typescript", "tailwind", "javascript"])
        },
        {
            "title": "AI/ML Engineer",
            "company": "DataDriven Labs",
            "location": "Remote",
            "remote": True,
            "salary_min": 160000,
            "salary_max": 200000,
            "description": "Seeking an AI engineer experienced in LLMs, Python, and building production ML systems. Knowledge of FastAPI and cloud deployment a plus.",
            "url": "https://example.com/jobs/ai-engineer",
            "source": "linkedin",
            "required_skills": json.dumps(["python", "machine learning", "ai", "fastapi", "docker"])
        },
        {
            "title": "Full Stack Developer",
            "company": "GlobalSoft",
            "location": "London, UK",
            "remote": True,
            "salary_min": 80000,
            "salary_max": 110000,
            "description": "Full stack role involving React, Node.js or Python backend, and PostgreSQL. Remote-friendly team.",
            "url": "https://example.com/jobs/fullstack",
            "source": "glassdoor",
            "required_skills": json.dumps(["react", "python", "javascript", "postgresql", "node.js"])
        },
        {
            "title": "DevOps Engineer",
            "company": "CloudScale",
            "location": "Austin, TX",
            "remote": False,
            "salary_min": 130000,
            "salary_max": 160000,
            "description": "Experience with Kubernetes, Docker, AWS, CI/CD pipelines required. Python scripting helpful.",
            "url": "https://example.com/jobs/devops",
            "source": "wellfound",
            "required_skills": json.dumps(["docker", "kubernetes", "aws", "python", "git"])
        }
    ]
    for j in sample_jobs:
        job = Job(**{k: v for k, v in j.items() if k != "required_skills"}, required_skills=j["required_skills"])
        db.add(job)
    db.commit()
    logger.info("Seeded sample jobs")

@app.on_event("startup")
def startup():
    db = SessionLocal()
    seed_sample_jobs(db)
    db.close()

@app.post("/register")
def register(user: UserCreate, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.email == user.email).first()
    if db_user:
        raise HTTPException(status_code=400, detail="Email already registered")
    hashed = get_password_hash(user.password)
    new_user = User(email=user.email, hashed_password=hashed, full_name=user.full_name)
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    # Create default settings
    settings = UserSettings(user_id=new_user.id)
    db.add(settings)
    db.commit()
    return {"message": "User created", "user_id": new_user.id}

@app.post("/token")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect email or password")
    access_token = create_access_token(data={"sub": user.email})
    return {"access_token": access_token, "token_type": "bearer"}

@app.get("/me")
def read_users_me(current_user: User = Depends(get_current_user)):
    return {"id": current_user.id, "email": current_user.email, "full_name": current_user.full_name}

@app.get("/settings")
def get_settings(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    settings = db.query(UserSettings).filter(UserSettings.user_id == current_user.id).first()
    if not settings:
        settings = UserSettings(user_id=current_user.id)
        db.add(settings)
        db.commit()
        db.refresh(settings)
    return {
        "job_titles": json.loads(settings.job_titles or "[]"),
        "skills": json.loads(settings.skills or "[]"),
        "experience_level": settings.experience_level,
        "preferred_countries": json.loads(settings.preferred_countries or "[]"),
        "remote_preference": settings.remote_preference,
        "min_salary": settings.min_salary,
        "employment_type": settings.employment_type,
        "daily_application_limit": settings.daily_application_limit,
        "auto_apply_enabled": settings.auto_apply_enabled,
        "require_approval": settings.require_approval
    }

@app.put("/settings")
def update_settings(update: UserSettingsUpdate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    settings = db.query(UserSettings).filter(UserSettings.user_id == current_user.id).first()
    if not settings:
        settings = UserSettings(user_id=current_user.id)
        db.add(settings)
    settings.job_titles = json.dumps(update.job_titles)
    settings.skills = json.dumps(update.skills)
    settings.experience_level = update.experience_level
    settings.preferred_countries = json.dumps(update.preferred_countries)
    settings.remote_preference = update.remote_preference
    settings.min_salary = update.min_salary
    settings.employment_type = update.employment_type
    settings.daily_application_limit = update.daily_application_limit
    settings.auto_apply_enabled = update.auto_apply_enabled
    settings.require_approval = update.require_approval
    db.commit()
    return {"message": "Settings updated"}

@app.post("/resumes/upload")
async def upload_resume(file: UploadFile = File(...), current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    content = await file.read()
    text = ""
    if file.filename.endswith(".pdf"):
        text = extract_text_from_pdf(content)
    elif file.filename.endswith(".docx"):
        text = extract_text_from_docx(content)
    else:
        raise HTTPException(400, "Only PDF and DOCX supported")
    skills = simple_skill_extract(text)
    resume = Resume(
        user_id=current_user.id,
        filename=file.filename,
        content=text[:10000],  # limit size
        skills=json.dumps(skills),
        experience="Extracted from resume",
        education="Extracted from resume"
    )
    db.add(resume)
    db.commit()
    db.refresh(resume)
    return {"id": resume.id, "filename": resume.filename, "skills": skills, "preview": text[:500]}

@app.get("/resumes")
def list_resumes(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    resumes = db.query(Resume).filter(Resume.user_id == current_user.id).all()
    return [{"id": r.id, "filename": r.filename, "skills": json.loads(r.skills or "[]"), "uploaded_at": r.uploaded_at} for r in resumes]

@app.get("/jobs")
def list_jobs(
    title: Optional[str] = None,
    remote: Optional[bool] = None,
    min_salary: Optional[int] = None,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    query = db.query(Job)
    if title:
        query = query.filter(Job.title.ilike(f"%{title}%"))
    if remote is not None:
        query = query.filter(Job.remote == remote)
    if min_salary:
        query = query.filter(Job.salary_min >= min_salary)
    jobs = query.all()
    # Calculate scores if user has resume
    latest_resume = db.query(Resume).filter(Resume.user_id == current_user.id).order_by(Resume.uploaded_at.desc()).first()
    results = []
    for job in jobs:
        score = None
        if latest_resume:
            job_skills = json.loads(job.required_skills or "[]")
            resume_skills = json.loads(latest_resume.skills or "[]")
            score = calculate_compatibility(resume_skills, job_skills, latest_resume.content or "", job.description)
        results.append({
            "id": job.id,
            "title": job.title,
            "company": job.company,
            "location": job.location,
            "remote": job.remote,
            "salary_min": job.salary_min,
            "salary_max": job.salary_max,
            "description": job.description[:300] + "...",
            "url": job.url,
            "source": job.source,
            "compatibility_score": round(score, 1) if score else None
        })
    return results

@app.post("/applications")
def create_application(app_data: ApplicationCreate, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    job = db.query(Job).filter(Job.id == app_data.job_id).first()
    if not job:
        raise HTTPException(404, "Job not found")
    # Generate cover letter if not provided
    cover = app_data.cover_letter
    if not cover:
        resume = None
        if app_data.resume_id:
            resume = db.query(Resume).filter(Resume.id == app_data.resume_id, Resume.user_id == current_user.id).first()
        summary = resume.content[:200] if resume else "relevant experience"
        cover = generate_cover_letter(current_user.full_name, job.title, job.company, summary, job.description)
    # Score
    score = 0.0
    if app_data.resume_id:
        resume = db.query(Resume).filter(Resume.id == app_data.resume_id).first()
        if resume:
            job_skills = json.loads(job.required_skills or "[]")
            resume_skills = json.loads(resume.skills or "[]")
            score = calculate_compatibility(resume_skills, job_skills, resume.content or "", job.description)
    application = Application(
        user_id=current_user.id,
        job_id=app_data.job_id,
        resume_id=app_data.resume_id,
        cover_letter=cover,
        status="ready",
        compatibility_score=score
    )
    db.add(application)
    db.commit()
    db.refresh(application)
    return {"id": application.id, "status": application.status, "cover_letter": cover[:200] + "...", "score": round(score, 1)}

@app.get("/applications")
def list_applications(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    apps = db.query(Application).filter(Application.user_id == current_user.id).all()
    results = []
    for a in apps:
        job = a.job
        results.append({
            "id": a.id,
            "job_title": job.title,
            "company": job.company,
            "url": job.url,
            "status": a.status,
            "applied_at": a.applied_at,
            "compatibility_score": a.compatibility_score,
            "cover_letter_preview": (a.cover_letter or "")[:150] + "..."
        })
    return results

@app.post("/applications/{app_id}/apply")
def mark_applied(app_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    # In production this would trigger Playwright or API submission
    # Here we simulate and note limitations
    application = db.query(Application).filter(Application.id == app_id, Application.user_id == current_user.id).first()
    if not application:
        raise HTTPException(404, "Application not found")
    settings = db.query(UserSettings).filter(UserSettings.user_id == current_user.id).first()
    if settings and settings.require_approval:
        # Still allow manual mark
        pass
    application.status = "applied"
    application.applied_at = datetime.utcnow()
    db.commit()
    return {
        "message": "Application marked as submitted (demo mode). Real auto-apply requires authorized APIs or permitted browser automation and user consent. Most major job sites block unauthenticated automation.",
        "status": application.status,
        "manual_link": application.job.url
    }

@app.get("/dashboard")
def dashboard(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    total_jobs = db.query(Job).count()
    apps = db.query(Application).filter(Application.user_id == current_user.id).all()
    submitted = len([a for a in apps if a.status == "applied"])
    pending = len([a for a in apps if a.status in ["saved", "ready"]])
    interviews = len([a for a in apps if a.status == "interview"])
    # Matching jobs (score > 60)
    matching = 0
    latest_resume = db.query(Resume).filter(Resume.user_id == current_user.id).order_by(Resume.uploaded_at.desc()).first()
    if latest_resume:
        jobs = db.query(Job).all()
        for job in jobs:
            job_skills = json.loads(job.required_skills or "[]")
            resume_skills = json.loads(latest_resume.skills or "[]")
            score = calculate_compatibility(resume_skills, job_skills, latest_resume.content or "", job.description)
            if score >= 60:
                matching += 1
    return {
        "total_jobs_found": total_jobs,
        "matching_jobs": matching,
        "applications_submitted": submitted,
        "pending_applications": pending,
        "interview_invitations": interviews,
        "recent_applications": len(apps)
    }

@app.get("/")
def root():
    return {"message": "AI Job Hunter API is running", "docs": "/docs", "status": "ok"}

@app.get("/health")
def health():
    return {
        "status": "healthy",
        "service": "AI Job Hunter API",
        "timestamp": datetime.utcnow().isoformat()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
