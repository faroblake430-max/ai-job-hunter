# To integrate a real LLM (example with OpenAI):

# 1. pip install openai
# 2. Set OPENAI_API_KEY in environment
# 3. Replace generate_cover_letter and calculate_compatibility functions in main.py

# Example replacement for cover letter:
# from openai import OpenAI
# client = OpenAI()
# def generate_cover_letter(...):
#     response = client.chat.completions.create(
#         model="gpt-4o-mini",
#         messages=[{"role": "system", "content": "You are a professional cover letter writer. Never invent experience."},
#                   {"role": "user", "content": f"Write a cover letter for {job_title} at {company} based on: {resume_summary} and job: {job_desc}"}]
#     )
#     return response.choices[0].message.content
