# AI Job Hunter – Deployment Guide

This guide gets you a **public live URL** in about 15–20 minutes.

## Prerequisites

1. A free [GitHub](https://github.com) account
2. A free [Render](https://render.com) account (sign up with GitHub)
3. A free [Vercel](https://vercel.com) account (sign up with GitHub)

---

## Step 1: Push the code to GitHub

1. Create a new repository on GitHub (e.g. `ai-job-hunter`).
2. Upload or push this entire project folder to that repo.

```bash
cd ai-job-hunter
git init
git add .
git commit -m "Initial AI Job Hunter"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ai-job-hunter.git
git push -u origin main
```

---

## Step 2: Deploy Backend + Database on Render

1. Go to [render.com](https://render.com) → **New** → **Blueprint**.
2. Connect your GitHub repo.
3. Render will detect `render.yaml` and create:
   - A **PostgreSQL** database (`ai-job-hunter-db`)
   - A web service (`ai-job-hunter-api`)
4. Click **Apply**.
5. Wait 3–5 minutes for the build.
6. Once deployed, copy the **Service URL** (looks like `https://ai-job-hunter-api.onrender.com`).

**Important environment variables** (already set by `render.yaml`):
- `DATABASE_URL` → automatically linked to the Postgres database
- `SECRET_KEY` → auto-generated

You can also add:
- `ALLOWED_ORIGINS` = `https://your-frontend.vercel.app` (add this after frontend is deployed)

---

## Step 3: Deploy Frontend on Vercel

1. Go to [vercel.com](https://vercel.com) → **Add New** → **Project**.
2. Import your GitHub repo.
3. Set **Root Directory** to `frontend`.
4. Under **Environment Variables**, add:

| Name | Value |
|------|--------|
| `NEXT_PUBLIC_API_URL` | `https://ai-job-hunter-api.onrender.com` (your Render URL) |

5. Click **Deploy**.
6. After deployment, copy your Vercel URL (e.g. `https://ai-job-hunter.vercel.app`).

---

## Step 4: Update CORS (optional but recommended)

1. Go back to Render → your web service → **Environment**.
2. Add or update:
   - `ALLOWED_ORIGINS` = `https://your-app.vercel.app,https://your-app-*.vercel.app`
3. Redeploy the service (or it will pick up on next deploy).

---

## Step 5: Test the live site

1. Open your Vercel URL.
2. Register a new account.
3. Upload a resume (PDF or DOCX).
4. Go to Jobs → you should see sample jobs with match scores.
5. Prepare an application and check the Applications tracker.

---

## Free Tier Notes

- Render free web services spin down after 15 minutes of inactivity (first request after sleep takes ~30–50 seconds).
- Postgres free tier is sufficient for this demo.
- Vercel free tier is generous for the frontend.

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| CORS error | Make sure `ALLOWED_ORIGINS` includes your Vercel domain |
| Database connection failed | Check `DATABASE_URL` is set and starts with `postgresql://` |
| Frontend shows blank / API errors | Verify `NEXT_PUBLIC_API_URL` is correct and has no trailing slash |
| Resume upload fails | File size limit; try a smaller PDF |

Once both services are deployed, your live URL is the **Vercel frontend URL**.
